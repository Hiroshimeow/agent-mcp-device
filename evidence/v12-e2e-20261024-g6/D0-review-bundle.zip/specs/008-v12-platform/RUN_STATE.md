# MCP Device v12 + Palace — RUN_STATE

**RELEASE_BLOCKED_WITH_EVIDENCE**

- Cập nhật: 2026-10-24T11:33:52.300Z. Chỉ G6 qua md; không tác nhân phụ, không scheduler.
- Kho `E:/git-project/agent-mcp-device-v12`; nhánh `feat/v12-platform-20261022`; HEAD `1e454c1cdcbe3265892f751034fa389432d65405`. Working tree dirty; chưa commit do chưa có review bắt buộc.
- Báo cáo đầy đủ: `evidence/v12-e2e-20261024-g6/FINAL_REPORT.md`. Checklist máy đọc: `evidence/v12-e2e-20261024-g6/release-checklist.json`.
- Windows Node 22.22.2; WSL Ubuntu-22.04 Node 22.21.0.

## Gates

| Gate | Trạng thái | Bằng chứng / thiếu |
| --- | --- | --- |
| S0 | BLOCKED | Đã chụp G6 và bảo toàn WIP; G8 và review D0 nằm ngoài phạm vi chỉ G6 hiện hành. |
| S1 | FAIL | Cold install hai gói trên hai OS đạt; liên kết Skill hỏng sau di chuyển gói vẫn tái hiện. Lifecycle upgrade/disable/uninstall và notice của gói độc lập chưa khép lại. |
| S2 | BLOCKED | Read-only CLI, budget, evidence semantics và 1.000 live reads đạt. Chính sách mutation/learning khi runtime hoạt động chưa được D0 chấp thuận và kiểm chứng. |
| S3 | NOT_RUN | Chưa có phiên Pi/Codex thật tự khám phá và dùng Skill; việc tạo tệp Skill trong HOME fixture không thay thế gate này. |
| S4 | NOT_RUN | Chưa có hai candidate từ công việc thật, procedure được tái hiện độc lập hoặc corpus truy vấn thực được gán nhãn trước. |
| S5 | NOT_RUN | 0 cặp A/B với usage từ provider; input/output/billed tokens và CI chưa đo. Tiết kiệm token: NOT_PROVEN. |
| S6 | FAIL | Platform 87/87 và server 42/42 mỗi OS đạt; Core comparator đạt. Native parity còn ba lỗi ở cả v11/v12, hai no-op bị loại khỏi acceptance, và các nhóm/cross-OS/upgrade chưa chạy đủ. |
| S7 | NOT_RUN | Chưa chạy soak 24 giờ hoặc so sánh tải nền/CPU/RSS của writer. Stress 1.000 CLI ngắn không được tính là soak. |
| S8 | BLOCKED | Chưa cập nhật G8, chưa có production rollback verification; phạm vi chỉ G6 và các release gate chưa qua. |
| S9 | BLOCKED | Không triển khai fleet. FJP được loại trừ; Z99 offline và chưa có artifact/lệnh nâng cấp được chấp nhận. |

## Bằng chứng cuối

- Platform 87/87 mỗi OS, server 42/42 mỗi OS, đều không skip.
- Root npm test 66 module exit 0; không dùng làm 66 assertion suites vì entrypoint legacy có no-op.
- Core comparator PASS 14 result + 4 side-effect families; port-free parity 35 PASS / 6 FAIL, trong PASS có 2 no-op bị loại. Ba failure xuất hiện trên cả baseline/candidate.
- Live CLI cuối: 1000/1000, 111 appends, SQLite integrity ok, elapsed 58.521 s; không phải 24h soak hoặc token evidence.
- Device SHA `e494d7be162390b1aaf2359112e103b1cbcad13885c71b21c9a5b948c3d8343b`. Palace SHA `db27ab6c60cbb14eb65ffd25424ed9bd867868061c332dba0d1353b9590133a6`.
- Artifact source `cc68ed16ff0e5bd64ffdc977eb2d2ba53f1592b5c2486178ecfed992617ce39d`; validation source `6876ad09877e2facd2a71eb66256862980ba0fd5c28fd4bc98bb849612174e26`.
- Bảy WIP gốc có backup khớp. Installer là WIP duy nhất được sửa có chủ đích; 347 canonical dist files không đổi. Diff patch check PASS.
- G6 live vẫn 1.0.11; 8101/8102 PID 47816, 8103 PID 50388, 8104 đã nhả. Không deployment.

## Các file / workspace để tiếp tục

- Evidence: `E:\git-project\agent-mcp-device-v12\evidence\v12-e2e-20261024-g6`.
- Artifact: `E:\test\mcp-device-v12-e2e-20261024-g6\artifacts\final`.
- Bản nguồn/validation: `E:\test\mcp-device-v12-e2e-20261024-g6\candidate-three`.
- Git worktree parity riêng: `E:\test\mcp-device-v12-e2e-20261024-g6\parity-worktree` (detached HEAD, nội dung xác minh bằng manifest; không coi Git status của bản copy là thay đổi tại kho chính).
- Raw parity runs: `E:\test\mcp-device-v12-e2e-20261024-g6\windows\parity-port-free`; receipt/log đã chép vào evidence.
- Linux native retained: `/var/tmp/mcp-device-v12-e2e-20261024-g6/final`. /tmp trước đó đã mất; receipts còn trên ổ E.
- D0 packet chuẩn bị, chưa gửi; không turn ID/verified model/verdict. D1–D3 NOT_RUN.

## Tiếp tục an toàn

1. Đọc FINAL_REPORT.md, release-checklist.json và preservation-and-diff.json; xác minh lại Git HEAD, các port và receipt trước mọi retry.
2. Review D0 trên FJP cần phạm vi vượt giới hạn chỉ G6 hiện tại. Không giả signoff hoặc thay reviewer.
3. Khép lại Skill ownership/relocation/uninstall, notice gói và parity failures; không sửa baseline v11 hoặc bỏ qua no-op.
4. Chạy real agent/procedure/token evidence, >=24h soak và D3 trên artifact cuối; chỉ sau đó mới G8/fleet rollout.
5. Không có retained job/soak đang chạy. Timeout md phải được đối chiếu với receipt, không gửi lặp mutation khi chưa rõ trạng thái.

Review bundle sẵn sàng tại evidence/v12-e2e-20261024-g6/D0-review-bundle.zip; chưa gửi. Kiểm chứng cuối: final-verification.json và evidence-index.json cùng thư mục.

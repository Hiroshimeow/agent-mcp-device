# MCP Device v12 + Palace — báo cáo G6

**RELEASE_BLOCKED_WITH_EVIDENCE**

Đã sửa các lỗi có bằng chứng, đóng gói và kiểm tra bản ứng viên trên Windows/WSL của G6. Các gate phát hành còn thiếu hoặc thất bại được giữ nguyên trạng thái; không có phê duyệt Opus, npm publish, tag, push hay triển khai.

## 1. Nguồn, phiên bản và bảo toàn

- Phiên bản ứng viên: `1.0.12`. Kho: `E:/git-project/agent-mcp-device-v12`.
- Nhánh: `feat/v12-platform-20261022`; HEAD: `1e454c1cdcbe3265892f751034fa389432d65405`.
- Working tree còn dirty; không tạo commit khi các slice chưa được review bắt buộc.
- Nguồn build: `cc68ed16ff0e5bd64ffdc977eb2d2ba53f1592b5c2486178ecfed992617ce39d`. Nguồn validation sau sửa cleanup của test: `6876ad09877e2facd2a71eb66256862980ba0fd5c28fd4bc98bb849612174e26`. Runtime sau rebuild được xác nhận trùng toàn bộ manifest tarball.
- Bảy WIP/đặc tả ban đầu có bản sao byte-identical. Chỉ installer WIP được sửa có chủ đích; các WIP khác giữ nguyên. Không có thay đổi ngoài danh sách dự kiến; 347 tệp dist của kho chính không đổi.
- Diff: [implementation-diff.patch](implementation-diff.patch); kiểm tra áp vào trước-image: [patch-check.json](patch-check.json) (PASS, không thực sự apply vào baseline). Kiểm kê: [preservation-and-diff.json](preservation-and-diff.json).

Các thay đổi: CLI giữ ngân sách byte gồm newline và abstain truy vấn rỗng token; installer giữ bản Skill đã sửa/thêm tệp; fallback phiên bản đồng bộ 1.0.12; test hợp đồng theo v12; test Windows chờ owned child đóng trước khi xóa cwd. Hai file regression mới: palace-cli-contract và palace-skill-preservation.

## 2. Artifact bất biến — chưa được chấp nhận phát hành

| Gói | Bytes | SHA-256 |
| --- | --- | --- |
| mcp-device | 2128581 | `e494d7be162390b1aaf2359112e103b1cbcad13885c71b21c9a5b948c3d8343b` |
| palace | 35288 | `db27ab6c60cbb14eb65ffd25424ed9bd867868061c332dba0d1353b9590133a6` |

- mcp-device: `E:\test\mcp-device-v12-e2e-20261024-g6\artifacts\final\hcu-lab.me-mcp-device-1.0.12.tgz`
- palace: `E:\test\mcp-device-v12-e2e-20261024-g6\artifacts\final\hcu-lab.me-palace-1.0.12.tgz`

Manifest đầy đủ: [artifacts-final.json](artifacts-final.json). Gói Palace không có dependency tới MCP Device. Inventory của Palace hiện thiếu tệp LICENSE; cần khép lại trước phân phối công khai.

## 3. S0–S9

| Gate | Trạng thái | Kết quả / phần thiếu | Bằng chứng |
| --- | --- | --- | --- |
| S0 | BLOCKED | Đã chụp G6 và bảo toàn WIP; G8 và review D0 nằm ngoài phạm vi chỉ G6 hiện hành. | [environment.json](environment.json) · [preservation-and-diff.json](preservation-and-diff.json) · [D0-review-packet.md](D0-review-packet.md) |
| S1 | FAIL | Cold install hai gói trên hai OS đạt; liên kết Skill hỏng sau di chuyển gói vẫn tái hiện. Lifecycle upgrade/disable/uninstall và notice của gói độc lập chưa khép lại. | [final-package/cold-win32-mcp-device.json](final-package/cold-win32-mcp-device.json) · [final-package/cold-linux-mcp-device.json](final-package/cold-linux-mcp-device.json) · [cold-win32-palace.json](cold-win32-palace.json) · [final-package/cold-linux-palace.json](final-package/cold-linux-palace.json) · [skill-safety-after.json](skill-safety-after.json) |
| S2 | BLOCKED | Read-only CLI, budget, evidence semantics và 1.000 live reads đạt. Chính sách mutation/learning khi runtime hoạt động chưa được D0 chấp thuận và kiểm chứng. | [cli-contract-green.json](cli-contract-green.json) · [platform-windows-final.json](platform-windows-final.json) · [live-cli-1000-windows-final-result.json](live-cli-1000-windows-final-result.json) |
| S3 | NOT_RUN | Chưa có phiên Pi/Codex thật tự khám phá và dùng Skill; việc tạo tệp Skill trong HOME fixture không thay thế gate này. | [final-package/cold-win32-mcp-device.json](final-package/cold-win32-mcp-device.json) · [final-package/cold-linux-mcp-device.json](final-package/cold-linux-mcp-device.json) |
| S4 | NOT_RUN | Chưa có hai candidate từ công việc thật, procedure được tái hiện độc lập hoặc corpus truy vấn thực được gán nhãn trước. | Chưa chạy |
| S5 | NOT_RUN | 0 cặp A/B với usage từ provider; input/output/billed tokens và CI chưa đo. Tiết kiệm token: NOT_PROVEN. | [actual-token-ab.json](actual-token-ab.json) |
| S6 | FAIL | Platform 87/87 và server 42/42 mỗi OS đạt; Core comparator đạt. Native parity còn ba lỗi ở cả v11/v12, hai no-op bị loại khỏi acceptance, và các nhóm/cross-OS/upgrade chưa chạy đủ. | [platform-windows-final.json](platform-windows-final.json) · [platform-linux-final.json](platform-linux-final.json) · [server-suite-windows-final.json](server-suite-windows-final.json) · [server-suite-linux-final.json](server-suite-linux-final.json) · [core-parity-windows-final.json](core-parity-windows-final.json) · [parity-interpretation.json](parity-interpretation.json) |
| S7 | NOT_RUN | Chưa chạy soak 24 giờ hoặc so sánh tải nền/CPU/RSS của writer. Stress 1.000 CLI ngắn không được tính là soak. | [soak-status.json](soak-status.json) · [live-cli-1000-windows-final-result.json](live-cli-1000-windows-final-result.json) |
| S8 | BLOCKED | Chưa cập nhật G8, chưa có production rollback verification; phạm vi chỉ G6 và các release gate chưa qua. | [runtime-after.json](runtime-after.json) · [g6-after-metadata.json](g6-after-metadata.json) |
| S9 | BLOCKED | Không triển khai fleet. FJP được loại trừ; Z99 offline và chưa có artifact/lệnh nâng cấp được chấp nhận. | [../fleet-rollout.json](../fleet-rollout.json) |

## 4. Hai demo cài đặt đã thực hiện

Các demo dùng npm install --omit=dev --no-audit --no-fund --save-exact trên tarball thật, scripts bật, prefix mới và MCP_DEVICE_SKILL_HOME riêng. Không dựa vào node_modules của checkout.

| Demo | Windows | Linux | Hành vi kiểm chứng |
| --- | --- | --- | --- |
| Palace độc lập | [cold-win32-palace.json](cold-win32-palace.json) | [final-package/cold-linux-palace.json](final-package/cold-linux-palace.json) | Không có gói Device; bin Palace thật; plugin ingest/search/read; evidence gốc được xác minh; dữ liệu đọc lại được sau stop |
| MCP Device mặc định | [final-package/cold-win32-mcp-device.json](final-package/cold-win32-mcp-device.json) | [final-package/cold-linux-mcp-device.json](final-package/cold-linux-mcp-device.json) | Default Palace và Skill trong .agents/skills, .pi/agent/skills của HOME fixture; CLI và source verification qua gói đã cài |

Vị trí Windows: `E:\test\mcp-device-v12-e2e-20261024-g6\windows\cold-palace` và `E:\test\mcp-device-v12-e2e-20261024-g6\windows\final\cold-device`. Linux cuối: `/var/tmp/mcp-device-v12-e2e-20261024-g6/final/palace` và `/var/tmp/mcp-device-v12-e2e-20261024-g6/final/mcp-device`.

Generic host disable trong server E2E giữ native read_file hoạt động và cached evidence dùng được. Đây không thay thế demo uninstall/upgrade package+Skill: dangling-link và cleanup lifecycle vẫn chưa đạt. Không tuyên bố agent thật đã tự khám phá Skill.

## 5. CLI live, evidence và learning

Các lệnh thực: palace --data-root <fixture-data> status; search COLD_PALACE_MARKER --limit 1; read <ID trả về>. Status/search/read trả ok=true, mode=read-only. Read báo evidenceVerifiedNow=false; kiểm chứng qua canonical provider trả verifiedBytes=true cho byte nguồn gốc. Các fixture nằm trong receipt cold tương ứng.

Artifact cuối chạy 1.000 CLI process, concurrency 4, luân phiên status/search/read/skills trong khi process Palace qua generic PluginHost index log bổ sung. Kết quả: 1.000/1.000, 0 lỗi, 111 append, 112 cards cuối, integrity_check=ok, writer lease thứ hai bị từ chối.

Thời gian 58.521 giây; p50 218.92 ms, p95 333.21 ms, p99 503.49 ms. Lượt này có workload parity khác trên G6; đây không phải so sánh hiệu năng được cô lập. RSS trong harness là của harness, không phải writer.

Raw 1.000 lượt: `E:\test\mcp-device-v12-e2e-20261024-g6\windows\final\live-cli-1000\cli-raw.jsonl`. Receipt: [live-cli-1000-windows-final-result.json](live-cli-1000-windows-final-result.json). Đây là fixture vận hành tổng hợp; chưa có một procedure từ công việc thật được tác tử độc lập tái hiện và chấp nhận.

## 6. A/B actual token

| Điều kiện | Số cặp | Input tokens | Output tokens | Billed tokens/cost | Correctness / paired 95% CI |
| --- | --- | --- | --- | --- | --- |
| Baseline | 0 | Chưa đo | Chưa đo | Chưa đo | Chưa đo |
| Palace treatment | 0 | Chưa đo | Chưa đo | Chưa đo | Chưa đo |

**Token savings: NOT_PROVEN.** Không suy từ byte JSON, số cards, MCP schema estimate hoặc bộ đếm tool. Thiết kế held-out, tối thiểu 20 cặp, raw provider usage và checker độc lập chưa chạy. [actual-token-ab.json](actual-token-ab.json).

## 7. Kiểm thử, parity và giới hạn

| Nhóm | Windows | Linux | Giới hạn |
| --- | --- | --- | --- |
| Platform | 87/87 PASS, 0 skip | 87/87 PASS, 0 skip | Runtime đối chiếu với manifest artifact |
| Server | 42/42 PASS, 0 skip | 42/42 PASS, 0 skip | Fixture xác thực/OAuth/pairing/restore; default catalog không có knowledge.* |
| Root npm test | 66/66 module exit 0 | Chưa chạy toàn bộ root runner | Một số entrypoint legacy no-op; không tính thành 66 assertion suites |
| Core comparator v11/v12 | PASS: 14 result families + 4 side-effect families | Chưa chạy comparator native tương ứng | Frozen v11 HEAD/dist không bị sửa |
| Port-free exported parity | 35 reported PASS / 6 FAIL trên 41 hàng | Chưa chạy | 2 PASS sanitizer là no-op bị loại khỏi acceptance; ba lỗi lặp trên cả hai phiên bản |

Các failed paired suites: test-edit-block-occurrences.js (success-message assertion); test-allowed-directories.js (C:/ root trong khi isolated home ở E:); test-symlink-security.js (EPERM khi tạo directory symlink). Không xóa lỗi, sửa baseline hoặc dùng việc cả hai cùng fail làm waiver. Xem [parity-interpretation.json](parity-interpretation.json), [parity-port-free-receipt.json](parity-port-free-receipt.json) và [parity-log-manifest.json](parity-log-manifest.json).

Full server suite có các compatibility fixture chủ động bật legacy knowledge MCP; test dual-listener mặc định xác nhận knowledge.* không được quảng bá. Các Device Core remote trong E2E là process fixture trên G6, không phải rollout máy khác.

Các lượt đỏ/harness failure được giữ: lỗi env skip installer ở baseline đầu; /tmp WSL mất giữa phiên; ba root contract lỗi cũ; EBUSY cleanup trước khi chờ child close; patch check ban đầu gặp test file đã thêm cho TDD. Receipt sửa tương ứng được ghi riêng, không ghi đè.

## 8. Soak, production và fleet

Soak 24 giờ: NOT_RUN; 0 giờ được chấp nhận; không có phiên soak đang chạy. Chưa đo so sánh CPU/RSS/load nền. Stress 58,5 giây không được đổi tên thành soak. [soak-status.json](soak-status.json).

G6 live vẫn 1.0.11, cùng device ID và connection epoch. Listener 8101/8102 vẫn PID 47816; 8103 vẫn PID 50388; 8104 đã nhả. Không thấy Node process mang marker thư mục fixture trong lần kiểm tra cuối; phép quét này không chứng minh mọi process không liên quan đều đã đóng.

Stopped-state backup/restore trong fixture Windows/Linux PASS, bao gồm paired identity, OAuth refresh và exact evidence. Production rollback: NOT_RUN. G8/Cloudflare không được kiểm tra hoặc thay đổi trong phạm vi chỉ G6.

Fleet: [../fleet-rollout.json](../fleet-rollout.json) và [../fleet-rollout.md](../fleet-rollout.md). Không máy nào được triển khai; FJP EXCLUDED_BY_USER. Z99 vẫn offline, chưa có safe upgrade command hoặc accepted artifact; không đánh dấu offline preparation hoàn tất.

## 9. Review và việc tiếp theo

| Review | Trạng thái | Turn ID | Model được xác minh | Verdict |
| --- | --- | --- | --- | --- |
| D0 | REVIEW_PENDING_G6_ONLY | null | Chưa có | Chưa có |
| D1 | NOT_RUN | null | Chưa có | Chưa có |
| D2 | NOT_RUN | null | Chưa có | Chưa có |
| D3 | NOT_RUN | null | Chưa có | Chưa có |

Yêu cầu đến từ V12_END_TO_END_COMPLETION_SPEC.md §7 và ONE_AGENT_EXECUTION_PROMPT.md: D0 phải có trước quyết định kiến trúc package/IPC; commit các slice đã review; D1–D3 theo milestone. Giới hạn chỉ G6 ngăn chạy reviewer yêu cầu trên FJP. Không tự duyệt thay Opus. Packet đã sẵn sàng: [D0-review-packet.md](D0-review-packet.md).

- **B1 — D0 reviewer / execution scope:** Đặc tả yêu cầu M365 Opus 5.5 trên FJP. Chỉ dẫn hiện hành chỉ cho G6, nên D0 chưa gửi; D1–D3 chưa chạy.
- **B2 — S1 Skill lifecycle:** Dangling managed Skill link sau package relocation; chưa có ownership record đủ để sửa/gỡ link an toàn. Copy có khác biệt được bảo toàn nên upgrade bản copy cũ còn hạn chế.
- **B3 — S1 package closure:** Inventory tarball Palace không có LICENSE trong khi package khai báo MIT; cần đưa notice phù hợp vào trước phân phối công khai.
- **B4 — D0 / S2 mutation contract:** Chưa quyết định có review liệu chỉ cho mutation khi runtime dừng có đủ cho agent workflow, hay cần mở rộng control path của writer hiện có.
- **B5 — S3–S5 real validation:** Chưa có real agent discovery/use, independently validated real procedure, corpus held-out và 20 paired tasks có actual provider token usage.
- **B6 — S6 parity harness and coverage:** Ba paired failures: expected edit-success text, root-directory fixture đặt C:/ trong khi home fixture nằm E:, và Windows directory symlink EPERM. Chưa waiver hoặc đổi baseline; root runner có no-op và sanitizer test dùng local copy thay vì production function.
- **B7 — S7 soak:** Không có soak >=24h hoặc số đo so sánh CPU/RSS/background load trên artifact cuối.
- **B8 — S8–S9 release:** Chưa có D3 SHIP, backup/rollback production được xác minh, G8 update, fleet rollout hoặc offline Z99 package preparation được chấp nhận.

Bước tiếp theo: giải quyết phạm vi review D0 trên FJP theo workflow đã chỉ định, dùng packet/diff/receipts sẵn có. Sau quyết định có review, hoàn thiện Skill ownership/lifecycle và package notice, khép lại các failure/coverage parity, chạy real-agent/procedure/token A/B, soak artifact cuối và D3. Chỉ sau đó mới cập nhật G8 và fleet theo backup/rollback đã xác minh.

Không có deployment, publication, review request đã gửi hoặc background soak chưa khai báo. Toàn bộ phiên thực thi G6 đã dừng ở checkpoint có bằng chứng này.

Bộ review đã chuẩn bị: [D0-review-bundle.zip](D0-review-bundle.zip), [bundle-manifest.json](bundle-manifest.json). Bản sao raw 1.000 lượt: [cli-live-final.jsonl](cli-live-final.jsonl). Kiểm chứng tệp: [final-verification.json](final-verification.json).

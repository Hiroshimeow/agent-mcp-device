#!/usr/bin/env node
// Assemble a separately installable Palace plugin/CLI from the SAME compiled source as MCP Device.
// This is a packaging adapter, not a second engine, MCP endpoint, or knowledge store.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../../', import.meta.url));
const output = path.join(root, '.tmp', 'v12-palace-standalone', 'package');
const pkg = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8'));
for (const item of ['dist/plugins/palace/plugin.js', 'dist/plugins/palace/cli.js', 'dist/log-palace/store.js', 'dist/log-palace/formats.js', 'dist/config.js']) {
  await fs.access(path.join(root, item));
}
await fs.rm(output, { recursive: true, force: true });
for (const item of ['dist/plugins/palace', 'dist/log-palace', 'skills/palace-cli']) {
  const target = path.join(output, item);
  await fs.mkdir(path.dirname(target), {recursive:true});
  await fs.cp(path.join(root, item), target, {recursive:true});
}
await fs.copyFile(path.join(root,'dist','config.js'), path.join(output,'dist','config.js'));
const manifest = {
  name: '@hcu-lab.me/palace',
  version: pkg.version,
  type: 'module',
  license: pkg.license || 'MIT',
  description: 'Read-only Palace CLI and independently installable knowledge plugin.',
  engines: {node: '>=22.13.0'},
  bin: {palace:'dist/plugins/palace/cli.js'},
  exports: {
    '.': './dist/plugins/palace/index.js',
    './plugin': './dist/plugins/palace/plugin.js',
    './cli': './dist/plugins/palace/cli.js',
    './skill': './skills/palace-cli/SKILL.md'
  },
  files:['dist','skills/palace-cli'],
  repository:pkg.repository,
  dependencies:{}
};
await fs.writeFile(path.join(output, 'package.json'), JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({ok:true,output,version:pkg.version,independentPackage:manifest.name}));

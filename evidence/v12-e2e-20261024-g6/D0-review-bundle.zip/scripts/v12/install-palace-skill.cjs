#!/usr/bin/env node
'use strict';
// Optional package-install convenience. Never replace a user-owned Skill.
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');

async function unchangedCopy(source, target, top = true) {
  // The legacy marker proves provenance, not permission to discard later edits.
  const [a, b] = await Promise.all([fs.lstat(source), fs.lstat(target)]);
  if (a.isSymbolicLink() || b.isSymbolicLink()) return false;
  if (a.isFile() && b.isFile()) return (await fs.readFile(source)).equals(await fs.readFile(target));
  if (!a.isDirectory() || !b.isDirectory()) return false;
  const names = await fs.readdir(source);
  const existing = (await fs.readdir(target)).filter(name => !top || name !== '.mcp-device-palace-owned');
  if (names.length !== existing.length || names.some(name => !existing.includes(name))) return false;
  for (const name of names) if (!await unchangedCopy(path.join(source, name), path.join(target, name), false)) return false;
  return true;
}

async function main() {
  if (process.env.MCP_DEVICE_SKIP_SKILL_INSTALL === '1') return {ok:true,skipped:'disabled'};
  const root = path.resolve(__dirname, '..','..');
  const inInstalledPackage = root.split(path.sep).some(x=>x.toLowerCase()==='node_modules');
  if (!inInstalledPackage && process.env.MCP_DEVICE_INSTALL_SKILLS_FORCE !== '1')
    return {ok:true,skipped:'development-checkout'};
  const source = path.join(root,'skills','palace-cli');
  await fs.access(path.join(source, 'SKILL.md'));
  const home = path.resolve(process.env.MCP_DEVICE_SKILL_HOME || os.homedir());
  const targets = [
    path.join(home,'.agents','skills','palace-cli'),
    path.join(home,'.pi','agent','skills','palace-cli')
  ];
  const result=[];
  for (const target of targets) {
    try {
      await fs.mkdir(path.dirname(target),{recursive:true});
      let present=false;
      try {await fs.lstat(target);present=true;} catch (err) {if (err.code !== 'ENOENT') throw err;}
      if (present) {
        try {
          if (await fs.realpath(target) === await fs.realpath(source)) {
            result.push({target,state:'already-installed'});continue;
          }
        } catch {}
        // A marker is only ever written by our copy fallback. Never overwrite an unmarked Skill.
        const marker = path.join(target,'.mcp-device-palace-owned');
        let owned=false;
        try {owned=(await fs.readFile(marker,'utf8')).trim()==='palace-cli';}catch{}
        if (!owned || !await unchangedCopy(source, target).catch(() => false)) {
          result.push({target,state:'preserved-existing'});continue;
        }
        await fs.rm(target,{recursive:true,force:true});
      }
      try {
        await fs.symlink(source,target,process.platform==='win32'?'junction':'dir');
        result.push({target,state:'linked'});
      } catch (symlinkError) {
        await fs.cp(source,target,{recursive:true,force:true});
        await fs.writeFile(path.join(target,'.mcp-device-palace-owned'),'palace-cli\n');
        result.push({target,state:'copied'});
      }
    }catch(err) {
      result.push({target,state:'failed',reason:err.code||err.message});
    }
  }
  return {ok:!result.some(item=>item.state==='failed'),skill:'palace-cli',result};
}
main().then(x=>console.log(JSON.stringify(x))).catch(e=>{
  // A filesystem location should not make the core MCP Device package fail to install.
  console.warn('[mcp-device] Palace Skill setup skipped: '+e.message);
});
